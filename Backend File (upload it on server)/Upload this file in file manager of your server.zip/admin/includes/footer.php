<footer class="app-footer">
      <div class="row">
        <div class="col-xs-12">
          <div class="footer-copyright">For any Queries <a href="http://wa.me/919339932830" target="_blank">WhatsApp Us</a> or <a href="mailto:wowcodes.in@gmail.com" target="_blank">Email Us</a></div>
          <div class="footer-copyright">Sold by  <a href="https://wowcodes.in" target="_blank">WowCodes </a> EXCLUSIVELY on <a href="https://codecanyon.net/user/wowcodes/portfolio" target="_blank"> Codecanyon.</a></div>
        </div>
      </div>
    </footer>
  </div>
</div>
<script type="text/javascript" src="assets/js/vendor.js"></script> 
<script type="text/javascript" src="assets/js/app.js"></script>
</body>
</html>